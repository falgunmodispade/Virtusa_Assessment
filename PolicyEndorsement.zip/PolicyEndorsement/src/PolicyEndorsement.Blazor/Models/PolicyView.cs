namespace PolicyEndorsement.Blazor.Models;

public sealed record PolicyView(
    string PolicyId,
    string Status,
    decimal Premium,
    int Version,
    string TermStart,
    string TermEnd,
    IReadOnlyList<EndorsementView> Endorsements);

public sealed record EndorsementView(
    string Id,
    string EffectiveDate,
    string ChangeDescription,
    decimal PremiumAfter);
