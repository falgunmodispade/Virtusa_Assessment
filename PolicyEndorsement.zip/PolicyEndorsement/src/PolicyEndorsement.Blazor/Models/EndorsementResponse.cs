namespace PolicyEndorsement.Blazor.Models;

public sealed record EndorsementResponse(
    string PolicyId,
    string Status,
    decimal Premium,
    int Version,
    string EndorsementId,
    string Summary);
