namespace PolicyEndorsement.Blazor.Models;

public sealed record EndorsementOutcome(
    bool IsSuccess,
    EndorsementResponse? Response,
    string? Code,
    string? Message,
    IReadOnlyDictionary<string, string> FieldErrors,
    int? CurrentVersion)
{
    public static EndorsementOutcome Success(EndorsementResponse response) =>
        new(true, response, null, null, new Dictionary<string, string>(), null);

    public static EndorsementOutcome Failure(
        string code,
        string message,
        IReadOnlyDictionary<string, string>? fieldErrors = null,
        int? currentVersion = null) =>
        new(false, null, code, message, fieldErrors ?? new Dictionary<string, string>(), currentVersion);
}
