namespace PolicyEndorsement.Blazor.Models;

public sealed record EndorseRequest(string EffectiveDate, string ChangeDescription, int ExpectedVersion);
