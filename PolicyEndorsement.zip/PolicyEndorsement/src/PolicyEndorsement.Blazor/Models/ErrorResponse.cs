namespace PolicyEndorsement.Blazor.Models;

public sealed record ErrorResponse(
    string Code,
    string Message,
    IReadOnlyDictionary<string, string>? Fields,
    int? CurrentVersion);
