using System.Net.Http.Json;
using PolicyEndorsement.Blazor.Models;

namespace PolicyEndorsement.Blazor.Services;

public sealed class PolicyApiClient
{
    private readonly HttpClient _http;

    public PolicyApiClient(HttpClient http)
    {
        _http = http;
    }

    public async Task<PolicyView?> GetPolicyAsync(string policyId, CancellationToken cancellationToken = default)
    {
        using var response = await _http.GetAsync(
            $"api/policies/{Uri.EscapeDataString(policyId)}",
            cancellationToken);

        if (!response.IsSuccessStatusCode)
        {
            return null;
        }

        return await response.Content.ReadFromJsonAsync<PolicyView>(cancellationToken: cancellationToken);
    }

    public async Task<EndorsementOutcome> EndorseAsync(
        string policyId,
        EndorseRequest request,
        CancellationToken cancellationToken = default)
    {
        try
        {
            using var response = await _http.PostAsJsonAsync(
                $"api/policies/{Uri.EscapeDataString(policyId)}/endorsements",
                request,
                cancellationToken);

            if (response.IsSuccessStatusCode)
            {
                var body = await response.Content.ReadFromJsonAsync<EndorsementResponse>(
                    cancellationToken: cancellationToken);

                return body is null
                    ? EndorsementOutcome.Failure("invalid_response", "The API returned an empty response.")
                    : EndorsementOutcome.Success(body);
            }

            var error = await response.Content.ReadFromJsonAsync<ErrorResponse>(
                cancellationToken: cancellationToken);

            return error is null
                ? EndorsementOutcome.Failure("unexpected_response", $"The request failed ({(int)response.StatusCode}).")
                : EndorsementOutcome.Failure(error.Code, error.Message, error.Fields, error.CurrentVersion);
        }
        catch (HttpRequestException)
        {
            return EndorsementOutcome.Failure(
                "connection_error",
                "The policy API is unavailable. Check that it is running.");
        }
        catch (TaskCanceledException)
        {
            return EndorsementOutcome.Failure(
                "timeout",
                "The request timed out. Reload the policy before retrying; it may already have been saved.");
        }
    }
}
