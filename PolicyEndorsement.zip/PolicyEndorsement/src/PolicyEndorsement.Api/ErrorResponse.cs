namespace PolicyEndorsement.Api;

public sealed record ErrorResponse(
    string Code,
    string Message,
    IReadOnlyDictionary<string, string>? Fields = null,
    int? CurrentVersion = null);
