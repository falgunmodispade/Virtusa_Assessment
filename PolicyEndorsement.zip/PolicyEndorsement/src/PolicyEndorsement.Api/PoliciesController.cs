using System.Globalization;
using Microsoft.AspNetCore.Mvc;
using PolicyEndorsement.Domain;

namespace PolicyEndorsement.Api;

[ApiController]
[Route("api/policies")]
public sealed class PoliciesController : ControllerBase
{
    private readonly PolicyService _policyService;
    private readonly IPolicyRepository _repository;

    public PoliciesController(PolicyService policyService, IPolicyRepository repository)
    {
        _policyService = policyService;
        _repository = repository;
    }

    [HttpGet("{policyId}")]
    public IActionResult Get([FromRoute] string policyId)
    {
        var policy = _repository.Get(policyId);
        if (policy is null)
        {
            return NotFound(new ErrorResponse("policy_not_found", "The policy was not found."));
        }

        return Ok(new PolicyResponse(
            policy.PolicyId,
            policy.Status.ToString(),
            policy.CurrentPremium,
            policy.Version,
            policy.TermStart.ToString("yyyy-MM-dd"),
            policy.TermEnd.ToString("yyyy-MM-dd"),
            policy.Endorsements.Select(e => new EndorsementSummary(
                e.Id,
                e.EffectiveDate.ToString("yyyy-MM-dd"),
                e.ChangeDescription,
                e.PremiumAfter)).ToArray()));
    }

    [HttpPost("{policyId}/endorsements")]
    public async Task<IActionResult> Endorse(
        [FromRoute] string policyId,
        [FromBody] EndorsePolicyRequest request,
        CancellationToken cancellationToken)
    {
        if (request is null)
        {
            return BadRequest(new ErrorResponse("invalid_request", "A JSON request body is required."));
        }

        if (!DateOnly.TryParseExact(
                request.EffectiveDate,
                "yyyy-MM-dd",
                CultureInfo.InvariantCulture,
                DateTimeStyles.None,
                out var effectiveDate))
        {
            return BadRequest(new ErrorResponse(
                "validation_error",
                "The request contains invalid values.",
                new Dictionary<string, string>
                {
                    ["effectiveDate"] = "Enter a valid effective date in yyyy-MM-dd format."
                }));
        }

        var domainRequest = new EndorsementRequest(
            effectiveDate,
            request.ChangeDescription ?? string.Empty,
            request.ExpectedVersion);

        var result = await _policyService.EndorsePolicyAsync(policyId, domainRequest, cancellationToken);
        return result.ToActionResult();
    }
}
