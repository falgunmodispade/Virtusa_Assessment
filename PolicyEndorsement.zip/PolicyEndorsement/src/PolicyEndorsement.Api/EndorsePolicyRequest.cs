namespace PolicyEndorsement.Api;

public sealed class EndorsePolicyRequest
{
    public string? EffectiveDate { get; set; }

    public string? ChangeDescription { get; set; }

    public int ExpectedVersion { get; set; }
}
