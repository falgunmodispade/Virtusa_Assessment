namespace PolicyEndorsement.Api;

public sealed record EndorsementResponse(
    string PolicyId,
    string Status,
    decimal Premium,
    int Version,
    string EndorsementId,
    string Summary);
