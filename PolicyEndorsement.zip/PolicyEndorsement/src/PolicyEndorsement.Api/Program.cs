using Microsoft.AspNetCore.Mvc;
using PolicyEndorsement.Api;
using PolicyEndorsement.Domain;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers();
builder.Services.Configure<ApiBehaviorOptions>(options => options.SuppressModelStateInvalidFilter = true);
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddSingleton<IPolicyRepository>(_ => InMemoryPolicyRepository.CreateSeeded());
builder.Services.AddSingleton<IPremiumCalculator, DeterministicPremiumCalculator>();
builder.Services.AddSingleton<PolicyService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseMiddleware<ExceptionMappingMiddleware>();
app.UseHttpsRedirection();
app.MapControllers();

app.Run();
