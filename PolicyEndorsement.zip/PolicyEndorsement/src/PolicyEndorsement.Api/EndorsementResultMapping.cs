using Microsoft.AspNetCore.Mvc;
using PolicyEndorsement.Domain;

namespace PolicyEndorsement.Api;

public static class EndorsementResultMapping
{
    public static IActionResult ToActionResult(this EndorsementResult result)
    {
        if (result.IsSuccess)
        {
            var policy = result.Policy!;
            var endorsement = result.Endorsement!;
            return new OkObjectResult(new EndorsementResponse(
                policy.PolicyId,
                policy.Status.ToString(),
                policy.CurrentPremium,
                policy.Version,
                endorsement.Id,
                endorsement.ChangeDescription));
        }

        var failure = result.Failure!;
        var statusCode = failure.Kind switch
        {
            EndorsementFailureKind.Validation => StatusCodes.Status400BadRequest,
            EndorsementFailureKind.NotFound => StatusCodes.Status404NotFound,
            EndorsementFailureKind.StaleVersion => StatusCodes.Status409Conflict,
            EndorsementFailureKind.InvalidTransition => StatusCodes.Status409Conflict,
            _ => StatusCodes.Status500InternalServerError
        };

        return new ObjectResult(new ErrorResponse(
            failure.Code,
            failure.Message,
            failure.FieldErrors.Count == 0 ? null : failure.FieldErrors,
            failure.CurrentVersion))
        {
            StatusCode = statusCode
        };
    }
}
