namespace PolicyEndorsement.Api;

public sealed record PolicyResponse(
    string PolicyId,
    string Status,
    decimal Premium,
    int Version,
    string TermStart,
    string TermEnd,
    IReadOnlyList<EndorsementSummary> Endorsements);

public sealed record EndorsementSummary(
    string Id,
    string EffectiveDate,
    string ChangeDescription,
    decimal PremiumAfter);
