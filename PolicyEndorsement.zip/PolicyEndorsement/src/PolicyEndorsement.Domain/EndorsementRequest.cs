namespace PolicyEndorsement.Domain;

public sealed record EndorsementRequest(DateOnly EffectiveDate, string ChangeDescription, int ExpectedVersion);
