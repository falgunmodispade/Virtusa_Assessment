namespace PolicyEndorsement.Domain;

public sealed record EndorsementFailure(
    EndorsementFailureKind Kind,
    string Code,
    string Message,
    IReadOnlyDictionary<string, string> FieldErrors,
    int? CurrentVersion = null);
