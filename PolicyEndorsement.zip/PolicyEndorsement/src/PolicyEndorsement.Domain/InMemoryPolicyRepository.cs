namespace PolicyEndorsement.Domain;

public sealed class InMemoryPolicyRepository : IPolicyRepository
{
    private readonly object _sync = new();
    private readonly Dictionary<string, Policy> _policies;

    public InMemoryPolicyRepository(IEnumerable<Policy> policies)
    {
        _policies = policies.ToDictionary(p => p.PolicyId, StringComparer.OrdinalIgnoreCase);
    }

    public static InMemoryPolicyRepository CreateSeeded() => new(new[]
    {
        new Policy("POL-1001", PolicyStatus.Issued, new DateOnly(2026, 1, 1), new DateOnly(2026, 12, 31), 1200m, 3, Array.Empty<Endorsement>()),
        new Policy("POL-2002", PolicyStatus.Cancelled, new DateOnly(2026, 1, 1), new DateOnly(2026, 12, 31), 850m, 1, Array.Empty<Endorsement>())
    });

    public Policy? Get(string policyId)
    {
        lock (_sync)
        {
            return _policies.TryGetValue(policyId, out var policy) ? policy : null;
        }
    }

    public IReadOnlyList<Policy> GetAll()
    {
        lock (_sync)
        {
            return _policies.Values.ToArray();
        }
    }

    public RepositoryUpdateStatus TryUpdate(
        string policyId,
        int expectedVersion,
        Func<Policy, Policy> update,
        out Policy? updatedPolicy)
    {
        lock (_sync)
        {
            if (!_policies.TryGetValue(policyId, out var current))
            {
                updatedPolicy = null;
                return RepositoryUpdateStatus.NotFound;
            }

            if (current.Version != expectedVersion)
            {
                updatedPolicy = current;
                return RepositoryUpdateStatus.VersionConflict;
            }

            var updated = update(current);
            _policies[policyId] = updated;
            updatedPolicy = updated;
            return RepositoryUpdateStatus.Success;
        }
    }
}
