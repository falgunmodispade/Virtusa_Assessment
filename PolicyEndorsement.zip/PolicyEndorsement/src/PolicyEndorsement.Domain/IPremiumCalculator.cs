namespace PolicyEndorsement.Domain;

public interface IPremiumCalculator
{
    decimal Calculate(Policy policy, DateOnly effectiveDate, string changeDescription);
}
