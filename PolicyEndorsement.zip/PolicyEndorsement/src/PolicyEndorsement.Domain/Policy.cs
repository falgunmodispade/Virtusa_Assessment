namespace PolicyEndorsement.Domain;

public sealed record Policy(
    string PolicyId,
    PolicyStatus Status,
    DateOnly TermStart,
    DateOnly TermEnd,
    decimal CurrentPremium,
    int Version,
    IReadOnlyList<Endorsement> Endorsements)
{
    public Policy ApplyEndorsement(Endorsement endorsement, decimal recalculatedPremium) =>
        this with
        {
            Status = PolicyStatus.Endorsed,
            CurrentPremium = recalculatedPremium,
            Version = Version + 1,
            Endorsements = Endorsements.Append(endorsement).ToArray()
        };
}
