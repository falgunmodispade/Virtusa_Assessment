namespace PolicyEndorsement.Domain;

public enum RepositoryUpdateStatus
{
    Success,
    NotFound,
    VersionConflict
}

public interface IPolicyRepository
{
    Policy? Get(string policyId);

    IReadOnlyList<Policy> GetAll();

    RepositoryUpdateStatus TryUpdate(
        string policyId,
        int expectedVersion,
        Func<Policy, Policy> update,
        out Policy? updatedPolicy);
}
