namespace PolicyEndorsement.Domain;

public sealed record Endorsement(
    string Id,
    DateOnly EffectiveDate,
    string ChangeDescription,
    decimal PremiumAfter,
    DateTimeOffset RecordedAtUtc);
