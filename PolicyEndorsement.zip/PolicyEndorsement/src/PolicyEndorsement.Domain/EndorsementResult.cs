namespace PolicyEndorsement.Domain;

public sealed record EndorsementResult(
    Policy? Policy,
    Endorsement? Endorsement,
    EndorsementFailure? Failure)
{
    public bool IsSuccess => Failure is null;

    public static EndorsementResult Succeeded(Policy policy, Endorsement endorsement) =>
        new(policy, endorsement, null);

    public static EndorsementResult Failed(EndorsementFailure failure) =>
        new(null, null, failure);
}
