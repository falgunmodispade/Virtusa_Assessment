namespace PolicyEndorsement.Domain;

public enum EndorsementFailureKind
{
    Validation,
    NotFound,
    StaleVersion,
    InvalidTransition
}
