namespace PolicyEndorsement.Domain;

public sealed class PolicyService
{
    private readonly IPolicyRepository _repository;
    private readonly IPremiumCalculator _calculator;

    public PolicyService(IPolicyRepository repository, IPremiumCalculator calculator)
    {
        _repository = repository;
        _calculator = calculator;
    }

    public Task<EndorsementResult> EndorsePolicyAsync(
        string policyId,
        EndorsementRequest request,
        CancellationToken cancellationToken = default)
    {
        cancellationToken.ThrowIfCancellationRequested();

        if (request.ExpectedVersion < 1)
        {
            return Task.FromResult(Validation(
                "expectedVersion",
                "Expected version must be at least 1."));
        }

        var description = request.ChangeDescription?.Trim() ?? string.Empty;
        if (description.Length is < 10 or > 200)
        {
            return Task.FromResult(Validation(
                "changeDescription",
                "Change description must be between 10 and 200 characters."));
        }

        var policy = _repository.Get(policyId);
        if (policy is null)
        {
            return Task.FromResult(EndorsementResult.Failed(new EndorsementFailure(
                EndorsementFailureKind.NotFound,
                "policy_not_found",
                "The policy was not found.",
                new Dictionary<string, string>())));
        }

        if (request.EffectiveDate < policy.TermStart || request.EffectiveDate > policy.TermEnd)
        {
            return Task.FromResult(Validation(
                "effectiveDate",
                "Effective date must fall within the policy term."));
        }

        if (policy.Status is not (PolicyStatus.Issued or PolicyStatus.Endorsed))
        {
            return Task.FromResult(EndorsementResult.Failed(new EndorsementFailure(
                EndorsementFailureKind.InvalidTransition,
                "invalid_transition",
                "Only issued or endorsed policies can be endorsed.",
                new Dictionary<string, string>(),
                policy.Version)));
        }

        var recalculatedPremium = _calculator.Calculate(policy, request.EffectiveDate, description);
        var endorsement = new Endorsement(
            Guid.NewGuid().ToString("N"),
            request.EffectiveDate,
            description,
            recalculatedPremium,
            DateTimeOffset.UtcNow);

        var updateStatus = _repository.TryUpdate(
            policyId,
            request.ExpectedVersion,
            current => current.ApplyEndorsement(endorsement, recalculatedPremium),
            out var updatedPolicy);

        if (updateStatus == RepositoryUpdateStatus.VersionConflict)
        {
            return Task.FromResult(EndorsementResult.Failed(new EndorsementFailure(
                EndorsementFailureKind.StaleVersion,
                "stale_version",
                "The policy changed before this endorsement could be saved.",
                new Dictionary<string, string>(),
                updatedPolicy?.Version ?? policy.Version)));
        }

        if (updateStatus == RepositoryUpdateStatus.NotFound)
        {
            return Task.FromResult(EndorsementResult.Failed(new EndorsementFailure(
                EndorsementFailureKind.NotFound,
                "policy_not_found",
                "The policy was not found.",
                new Dictionary<string, string>())));
        }

        return Task.FromResult(EndorsementResult.Succeeded(updatedPolicy!, endorsement));
    }

    private static EndorsementResult Validation(string field, string message) =>
        EndorsementResult.Failed(new EndorsementFailure(
            EndorsementFailureKind.Validation,
            "validation_error",
            "The request contains invalid values.",
            new Dictionary<string, string> { [field] = message }));
}
