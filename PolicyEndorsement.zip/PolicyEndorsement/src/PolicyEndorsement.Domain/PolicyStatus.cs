namespace PolicyEndorsement.Domain;

public enum PolicyStatus
{
    Draft,
    Underwriting,
    Bound,
    Issued,
    Endorsed,
    Cancelled
}
