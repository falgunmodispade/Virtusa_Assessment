namespace PolicyEndorsement.Domain;

public sealed class DeterministicPremiumCalculator : IPremiumCalculator
{
    public decimal Calculate(Policy policy, DateOnly effectiveDate, string changeDescription)
    {
        var seasonalAdjustment = (effectiveDate.Month % 3) * 5m;
        var descriptionAdjustment = (changeDescription.Trim().Length % 10) * 1.25m;
        return decimal.Round(policy.CurrentPremium + 40m + seasonalAdjustment + descriptionAdjustment, 2);
    }
}
