using PolicyEndorsement.Domain;

namespace PolicyEndorsement.Tests;

public class PolicyServiceTests
{
    private const string IssuedPolicyId = "POL-1001";
    private const string CancelledPolicyId = "POL-2002";
    private const string ValidDescription = "Add driver to policy";
    private static readonly DateOnly EffectiveDate = new(2026, 11, 19);

    [Fact]
    public async Task EndorsePolicy_WithValidRequest_UpdatesPolicyOnceAndReturnsCommittedValues()
    {
        var (service, repository, calculator) = CreateSystem();
        var original = repository.Get(IssuedPolicyId)!;
        var request = new EndorsementRequest(EffectiveDate, ValidDescription, original.Version);

        var result = await service.EndorsePolicyAsync(IssuedPolicyId, request);

        Assert.True(result.IsSuccess);
        Assert.Null(result.Failure);
        var expectedPremium = calculator.Calculate(original, EffectiveDate, ValidDescription);
        Assert.Equal(expectedPremium, result.Policy!.CurrentPremium);
        Assert.Equal(original.Version + 1, result.Policy.Version);
        Assert.Equal(PolicyStatus.Endorsed, result.Policy.Status);
        var endorsement = Assert.Single(result.Policy.Endorsements);
        Assert.Equal(result.Endorsement!.Id, endorsement.Id);
        Assert.Equal(EffectiveDate, endorsement.EffectiveDate);
        Assert.Equal(ValidDescription, endorsement.ChangeDescription);

        var persisted = repository.Get(IssuedPolicyId)!;
        Assert.Equal(expectedPremium, persisted.CurrentPremium);
        Assert.Equal(original.Version + 1, persisted.Version);
        Assert.Equal(PolicyStatus.Endorsed, persisted.Status);
        Assert.Single(persisted.Endorsements);
    }

    [Fact]
    public async Task EndorsePolicy_WithStaleVersion_IsRejectedWithoutChangingState()
    {
        var (service, repository, _) = CreateSystem();
        var original = repository.Get(IssuedPolicyId)!;
        var request = new EndorsementRequest(EffectiveDate, ValidDescription, original.Version - 1);

        var result = await service.EndorsePolicyAsync(IssuedPolicyId, request);

        Assert.False(result.IsSuccess);
        Assert.Equal(EndorsementFailureKind.StaleVersion, result.Failure!.Kind);
        Assert.Equal("stale_version", result.Failure.Code);
        Assert.Equal(original.Version, result.Failure.CurrentVersion);
        Assert.Equal(original, repository.Get(IssuedPolicyId));
    }

    [Fact]
    public async Task EndorsePolicy_OnCancelledPolicy_IsRejectedWithoutChangingState()
    {
        var (service, repository, _) = CreateSystem();
        var original = repository.Get(CancelledPolicyId)!;
        var request = new EndorsementRequest(EffectiveDate, ValidDescription, original.Version);

        var result = await service.EndorsePolicyAsync(CancelledPolicyId, request);

        Assert.False(result.IsSuccess);
        Assert.Equal(EndorsementFailureKind.InvalidTransition, result.Failure!.Kind);
        Assert.Equal("invalid_transition", result.Failure.Code);
        Assert.Empty(result.Failure.FieldErrors);
        Assert.Equal(original, repository.Get(CancelledPolicyId));
    }

    [Fact]
    public async Task EndorsePolicy_WithInvalidFields_IsRejectedWithoutChangingState()
    {
        var (service, repository, _) = CreateSystem();
        var original = repository.Get(IssuedPolicyId)!;

        var shortDescription = await service.EndorsePolicyAsync(
            IssuedPolicyId,
            new EndorsementRequest(EffectiveDate, "too short", original.Version));
        var oldVersion = await service.EndorsePolicyAsync(
            IssuedPolicyId,
            new EndorsementRequest(EffectiveDate, ValidDescription, 0));
        var outsideTerm = await service.EndorsePolicyAsync(
            IssuedPolicyId,
            new EndorsementRequest(new DateOnly(2027, 1, 1), ValidDescription, original.Version));

        Assert.Equal("changeDescription", Assert.Single(shortDescription.Failure!.FieldErrors).Key);
        Assert.Equal("expectedVersion", Assert.Single(oldVersion.Failure!.FieldErrors).Key);
        Assert.Equal("effectiveDate", Assert.Single(outsideTerm.Failure!.FieldErrors).Key);
        Assert.Equal(original, repository.Get(IssuedPolicyId));
    }

    [Fact]
    public async Task EndorsePolicy_ReplayingAcceptedRequest_DoesNotApplyPremiumTwice()
    {
        var (service, repository, _) = CreateSystem();
        var original = repository.Get(IssuedPolicyId)!;
        var request = new EndorsementRequest(EffectiveDate, ValidDescription, original.Version);

        var first = await service.EndorsePolicyAsync(IssuedPolicyId, request);
        var replay = await service.EndorsePolicyAsync(IssuedPolicyId, request);

        Assert.True(first.IsSuccess);
        Assert.False(replay.IsSuccess);
        Assert.Equal(EndorsementFailureKind.StaleVersion, replay.Failure!.Kind);
        var persisted = repository.Get(IssuedPolicyId)!;
        Assert.Equal(first.Policy!.CurrentPremium, persisted.CurrentPremium);
        Assert.Equal(original.Version + 1, persisted.Version);
        Assert.Single(persisted.Endorsements);
    }

    [Fact]
    public async Task EndorsePolicy_ForUnknownPolicy_ReturnsNotFound()
    {
        var (service, _, _) = CreateSystem();

        var result = await service.EndorsePolicyAsync(
            "POL-9999",
            new EndorsementRequest(EffectiveDate, ValidDescription, 1));

        Assert.False(result.IsSuccess);
        Assert.Equal(EndorsementFailureKind.NotFound, result.Failure!.Kind);
        Assert.Equal("policy_not_found", result.Failure.Code);
    }

    private static (PolicyService Service, InMemoryPolicyRepository Repository, IPremiumCalculator Calculator) CreateSystem()
    {
        var repository = InMemoryPolicyRepository.CreateSeeded();
        var calculator = new DeterministicPremiumCalculator();
        return (new PolicyService(repository, calculator), repository, calculator);
    }
}
